"""
QORX Action Engine — replaces n8n / Zapier / Make.

Key difference from a generic automation tool: this engine shares the exact
same connector registry and semantic model as the ingestion pipeline, and the
AI can *propose* a workflow directly from a conversation instead of requiring
the user to hand-build a trigger -> condition -> action chain node by node.

Every workflow passes through an approval gate by default. Auto-execution
without approval is only ever enabled per-workflow, after a customer has
manually approved several runs and confirmed the outcome was correct — this
mirrors the honesty principle of the rest of QORX: never let automation run
ahead of validated accuracy.
"""
from __future__ import annotations
from datetime import datetime
from typing import Any, Protocol

import asyncpg

from .schemas import ActionStep, RiskLevel, WorkflowDefinition, WorkflowRunResult


class ActionConnector(Protocol):
    """Write-capable counterpart to BaseConnector (ingestion). Each connector
    that supports actions implements this — e.g. SlackActionConnector,
    SalesforceActionConnector, WebhookActionConnector."""

    connector_type: str

    async def execute_action(self, action_id: str, params: dict[str, Any]) -> dict[str, Any]:
        """Executes a single action and returns a JSON-serializable result.
        Must raise on failure so the engine can log the error and halt the run."""
        ...


class ActionConnectorRegistry:
    """Dispatches action_id (e.g. 'slack.send_message') to the right connector."""

    def __init__(self):
        self._connectors: dict[str, ActionConnector] = {}

    def register(self, connector_type: str, connector: ActionConnector) -> None:
        self._connectors[connector_type] = connector

    async def execute(self, action_id: str, params: dict[str, Any]) -> dict[str, Any]:
        connector_type = action_id.split(".")[0]
        connector = self._connectors.get(connector_type)
        if connector is None:
            raise ValueError(f"No action connector registered for '{connector_type}'")
        return await connector.execute_action(action_id, params)


class ActionEngine:
    def __init__(self, db_pool: asyncpg.Pool, connector_registry: ActionConnectorRegistry):
        self.db_pool = db_pool
        self.registry = connector_registry

    # ------------------------------------------------------------------
    # Workflow authoring — usually called from the AI orchestrator's
    # `propose_workflow` tool, but equally usable from a manual builder UI.
    # ------------------------------------------------------------------
    async def create_workflow(self, definition: WorkflowDefinition) -> str:
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", definition.org_id)
            row = await conn.fetchrow(
                """
                INSERT INTO workflows (org_id, name, description, trigger_type,
                    trigger_config, action_steps, requires_approval, created_by, source_insight_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING workflow_id
                """,
                definition.org_id, definition.name, definition.description,
                definition.trigger_type.value, definition.trigger_config,
                [step.model_dump() for step in definition.action_steps],
                definition.requires_approval, definition.created_by, definition.source_insight_id,
            )
            return str(row["workflow_id"])

    # ------------------------------------------------------------------
    # Trigger evaluation — run on a scheduler (e.g. every 5 min) against all
    # active threshold/schedule workflows, plus called synchronously whenever
    # a new anomaly/insight is created (event-type triggers).
    # ------------------------------------------------------------------
    async def evaluate_threshold_triggers(self, org_id: str) -> list[str]:
        """Returns run_ids created for any workflow whose threshold condition fired."""
        created_runs = []
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            workflows = await conn.fetch(
                """
                SELECT workflow_id, trigger_config FROM workflows
                WHERE org_id = $1 AND is_active = true AND trigger_type = 'threshold'
                """,
                org_id,
            )
            for wf in workflows:
                if await self._threshold_condition_met(conn, org_id, wf["trigger_config"]):
                    run_id = await self._create_run(conn, org_id, wf["workflow_id"],
                                                      triggered_by={"type": "threshold"})
                    created_runs.append(run_id)
        return created_runs

    async def _threshold_condition_met(self, conn, org_id: str, config: dict[str, Any]) -> bool:
        """Evaluates e.g. {"metric_id": "sellout_vs_target", "operator": "<",
        "value": 0.8, "sustained_days": 3, "group_by": ["region"]} against
        recent metric values. Simplified reference implementation."""
        metric_id = config["metric_id"]
        operator = config["operator"]
        threshold_value = config["value"]
        sustained_days = config.get("sustained_days", 1)

        rows = await conn.fetch(
            """
            SELECT (payload->>'value')::numeric AS value
            FROM events
            WHERE org_id = $1 AND event_type = $2
            ORDER BY occurred_at DESC LIMIT $3
            """,
            org_id, metric_id, sustained_days,
        )
        if len(rows) < sustained_days:
            return False

        ops = {"<": lambda v: v < threshold_value, ">": lambda v: v > threshold_value,
               "<=": lambda v: v <= threshold_value, ">=": lambda v: v >= threshold_value}
        check = ops.get(operator)
        return check is not None and all(check(r["value"]) for r in rows)

    async def fire_event_trigger(self, org_id: str, event_type: str,
                                   context: dict[str, Any]) -> list[str]:
        """Called synchronously when an event-type trigger's matching event occurs
        (e.g. an anomaly is written to `insights`)."""
        created_runs = []
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            workflows = await conn.fetch(
                """
                SELECT workflow_id FROM workflows
                WHERE org_id = $1 AND is_active = true AND trigger_type = 'event'
                  AND trigger_config->>'event_type' = $2
                """,
                org_id, event_type,
            )
            for wf in workflows:
                run_id = await self._create_run(conn, org_id, wf["workflow_id"],
                                                  triggered_by={"type": "event", **context})
                created_runs.append(run_id)
        return created_runs

    async def _create_run(self, conn, org_id: str, workflow_id: str,
                            triggered_by: dict[str, Any]) -> str:
        wf = await conn.fetchrow("SELECT requires_approval FROM workflows WHERE workflow_id = $1", workflow_id)
        status = "pending_approval" if wf["requires_approval"] else "approved"
        row = await conn.fetchrow(
            """
            INSERT INTO workflow_runs (workflow_id, org_id, triggered_by, status)
            VALUES ($1, $2, $3, $4) RETURNING run_id
            """,
            workflow_id, org_id, triggered_by, status,
        )
        run_id = str(row["run_id"])
        if status == "approved":
            await self.execute_run(org_id, run_id)
        return run_id

    # ------------------------------------------------------------------
    # Approval
    # ------------------------------------------------------------------
    async def approve_run(self, org_id: str, run_id: str, approved_by_user_id: str) -> WorkflowRunResult:
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            await conn.execute(
                """
                UPDATE workflow_runs SET status = 'approved', approved_by = $1, approved_at = now()
                WHERE run_id = $2 AND org_id = $3
                """,
                approved_by_user_id, run_id, org_id,
            )
        return await self.execute_run(org_id, run_id)

    async def reject_run(self, org_id: str, run_id: str) -> None:
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            await conn.execute(
                "UPDATE workflow_runs SET status = 'rejected' WHERE run_id = $1 AND org_id = $2",
                run_id, org_id,
            )

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    async def execute_run(self, org_id: str, run_id: str) -> WorkflowRunResult:
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            run_row = await conn.fetchrow(
                "SELECT workflow_id, status FROM workflow_runs WHERE run_id = $1 AND org_id = $2",
                run_id, org_id,
            )
            if run_row["status"] not in ("approved",):
                return WorkflowRunResult(run_id=run_id, workflow_id=str(run_row["workflow_id"]),
                                          status=run_row["status"],
                                          error_message="Run is not in an executable state")

            workflow = await conn.fetchrow(
                "SELECT action_steps FROM workflows WHERE workflow_id = $1", run_row["workflow_id"],
            )
            await conn.execute(
                "UPDATE workflow_runs SET status = 'running', started_at = now() WHERE run_id = $1", run_id,
            )

        execution_log: list[dict[str, Any]] = []
        final_status = "success"
        error_message = None

        for step_raw in workflow["action_steps"]:
            step = ActionStep(**step_raw)
            try:
                result = await self.registry.execute(step.action_id, step.params)
                execution_log.append({"action_id": step.action_id, "result": result,
                                       "timestamp": datetime.utcnow().isoformat()})
            except Exception as exc:  # noqa: BLE001
                execution_log.append({"action_id": step.action_id, "error": str(exc),
                                       "timestamp": datetime.utcnow().isoformat()})
                final_status = "failed"
                error_message = str(exc)
                break  # halt on first failure — no partial silent automation

        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            await conn.execute(
                """
                UPDATE workflow_runs
                SET status = $1, execution_log = $2, error_message = $3, finished_at = now()
                WHERE run_id = $4
                """,
                final_status, execution_log, error_message, run_id,
            )

        return WorkflowRunResult(run_id=run_id, workflow_id=str(run_row["workflow_id"]),
                                  status=final_status, execution_log=execution_log,
                                  error_message=error_message)
