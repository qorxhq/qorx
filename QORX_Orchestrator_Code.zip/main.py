"""
QORX API — FastAPI entrypoint.

Run: uvicorn main:app --reload
"""
from __future__ import annotations
import os
from contextlib import asynccontextmanager

import anthropic
import asyncpg
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .action_engine import ActionConnectorRegistry, ActionEngine
from .orchestrator import QorxOrchestrator
from .rag_retriever import RAGRetriever
from .schemas import ChatRequest, ChatResponse, WorkflowRunResult
from .tools import ToolRegistry

DATABASE_URL = os.environ["QORX_DATABASE_URL"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]


async def embed_text(text: str) -> list[float]:
    """Placeholder embedding function — wire to Voyage/OpenAI in production."""
    raise NotImplementedError("Wire to embeddings provider")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.db_pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=20)
    app.state.anthropic_client = anthropic.AsyncAnthropic(api_key=ANTHROPIC_API_KEY)

    # Action Engine — register write-capable action connectors here as they're built
    # (e.g. app.state.action_registry.register("slack", SlackActionConnector(...)))
    app.state.action_registry = ActionConnectorRegistry()
    app.state.action_engine = ActionEngine(app.state.db_pool, app.state.action_registry)

    app.state.tool_registry = ToolRegistry(app.state.db_pool, action_engine=app.state.action_engine)
    app.state.retriever = RAGRetriever(app.state.db_pool, embed_fn=embed_text)
    app.state.orchestrator = QorxOrchestrator(
        anthropic_client=app.state.anthropic_client,
        tool_registry=app.state.tool_registry,
        retriever=app.state.retriever,
    )
    yield
    await app.state.db_pool.close()


app = FastAPI(title="QORX Decision Intelligence API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict to app domain in production
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_orchestrator() -> QorxOrchestrator:
    return app.state.orchestrator


@app.post("/v1/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, orchestrator: QorxOrchestrator = Depends(get_orchestrator)):
    """
    Main chat endpoint. Runs the full LangGraph-style pipeline:
    classify intent -> retrieve context -> plan tools -> execute -> synthesize.
    """
    try:
        conversation_id = req.conversation_id or await _create_conversation(req.org_id, req.user_id)
        response = await orchestrator.run(
            org_id=req.org_id,
            user_id=req.user_id,
            conversation_id=conversation_id,
            message=req.message,
        )
        await _persist_messages(conversation_id, req.message, response.answer)
        return response
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


async def _create_conversation(org_id: str, user_id: str) -> str:
    async with app.state.db_pool.acquire() as conn:
        row = await conn.fetchrow(
            "INSERT INTO conversations (org_id, user_id) VALUES ($1, $2) RETURNING conversation_id",
            org_id, user_id,
        )
        return str(row["conversation_id"])


async def _persist_messages(conversation_id: str, user_message: str, assistant_answer: str) -> None:
    async with app.state.db_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO messages (conversation_id, role, content) VALUES ($1, 'user', $2)",
            conversation_id, user_message,
        )
        await conn.execute(
            "INSERT INTO messages (conversation_id, role, content) VALUES ($1, 'assistant', $2)",
            conversation_id, assistant_answer,
        )


def get_action_engine() -> ActionEngine:
    return app.state.action_engine


@app.post("/v1/workflows/{run_id}/approve", response_model=WorkflowRunResult)
async def approve_workflow_run(
    run_id: str, org_id: str, user_id: str,
    action_engine: ActionEngine = Depends(get_action_engine),
):
    """Human-in-the-loop approval gate. A pending_approval run only executes
    after an explicit call here — this is what keeps QORX automation safer
    than a fire-and-forget n8n workflow: nothing runs without a checked decision
    behind it until a workflow has proven itself over several approved runs."""
    try:
        return await action_engine.approve_run(org_id, run_id, approved_by_user_id=user_id)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/v1/workflows/{run_id}/reject")
async def reject_workflow_run(
    run_id: str, org_id: str,
    action_engine: ActionEngine = Depends(get_action_engine),
):
    try:
        await action_engine.reject_run(org_id, run_id)
        return {"status": "rejected"}
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/v1/health")
async def health():
    return {"status": "ok"}
