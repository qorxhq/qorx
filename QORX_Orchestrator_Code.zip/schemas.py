"""
QORX AI Decision Engine — shared schemas.
"""
from __future__ import annotations
from datetime import date, datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field


class IntentType(str, Enum):
    DIAGNOSTIC = "diagnostic"        # "why did X happen"
    PREDICTIVE = "predictive"        # "what will happen"
    PRESCRIPTIVE = "prescriptive"    # "what should we do"
    LOOKUP = "lookup"                # "what is metric X right now"


class ChatRequest(BaseModel):
    org_id: str
    user_id: str
    conversation_id: Optional[str] = None
    message: str


class RetrievedContext(BaseModel):
    glossary_terms: list[dict[str, str]] = Field(default_factory=list)
    metric_definitions: list[dict[str, Any]] = Field(default_factory=list)
    org_memory_facts: list[str] = Field(default_factory=list)
    prior_qa: list[dict[str, str]] = Field(default_factory=list)


class ToolCall(BaseModel):
    tool_name: str
    arguments: dict[str, Any]


class ToolResult(BaseModel):
    tool_name: str
    result: dict[str, Any]
    error: Optional[str] = None


class MetricQueryArgs(BaseModel):
    metric_id: str
    filters: dict[str, Any] = Field(default_factory=dict)
    start: date
    end: date
    group_by: list[str] = Field(default_factory=list)


class RootCauseArgs(BaseModel):
    metric_id: str
    period_a_start: date
    period_a_end: date
    period_b_start: date
    period_b_end: date


class ForecastArgs(BaseModel):
    metric_id: str
    horizon_days: int = Field(gt=0, le=365)


class GenerateSQLArgs(BaseModel):
    natural_language_question: str


class OrchestratorState(BaseModel):
    """The full state object threaded through the LangGraph-style pipeline."""
    org_id: str
    user_id: str
    conversation_id: str
    user_message: str
    intent: Optional[IntentType] = None
    context: RetrievedContext = Field(default_factory=RetrievedContext)
    planned_tool_calls: list[ToolCall] = Field(default_factory=list)
    tool_results: list[ToolResult] = Field(default_factory=list)
    final_answer: Optional[str] = None
    chart_spec: Optional[dict[str, Any]] = None
    confidence: Optional[float] = None
    suggested_action: Optional[str] = None
    trace: list[str] = Field(default_factory=list)  # for Langfuse-style observability

    def log(self, step: str) -> None:
        self.trace.append(f"[{datetime.utcnow().isoformat()}] {step}")


class ChatResponse(BaseModel):
    conversation_id: str
    answer: str
    chart_spec: Optional[dict[str, Any]] = None
    confidence: Optional[float] = None
    suggested_action: Optional[str] = None
    tool_calls_made: list[str] = Field(default_factory=list)


# ============================================================================
# Action Engine — replaces n8n / Zapier / Make for the customer.
# A workflow is a trigger + an ordered list of action steps, executed through
# the same connectors already used for ingestion (write path instead of read).
# ============================================================================

class TriggerType(str, Enum):
    EVENT = "event"          # fires when a specific event_type lands in `events`
    SCHEDULE = "schedule"    # cron-based
    THRESHOLD = "threshold"  # metric crosses a condition, optionally sustained N days
    MANUAL = "manual"        # user-initiated, one-off or on-demand


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ActionStep(BaseModel):
    action_id: str                      # e.g. "slack.send_message", "salesforce.update_field"
    params: dict[str, Any] = Field(default_factory=dict)


class WorkflowDefinition(BaseModel):
    workflow_id: Optional[str] = None
    org_id: str
    name: str
    description: Optional[str] = None
    trigger_type: TriggerType
    trigger_config: dict[str, Any] = Field(default_factory=dict)
    action_steps: list[ActionStep]
    requires_approval: bool = True
    created_by: str = "user"            # "user" | "ai_suggested"
    source_insight_id: Optional[str] = None


class ProposeWorkflowArgs(BaseModel):
    """Tool args: the AI drafts a workflow from a natural-language description."""
    name: str
    description: str
    trigger_type: TriggerType
    trigger_config: dict[str, Any]
    action_steps: list[ActionStep]
    source_insight_id: Optional[str] = None


class ExecuteWorkflowArgs(BaseModel):
    """Tool args: run an already-approved workflow immediately (manual trigger)."""
    workflow_id: str


class WorkflowRunResult(BaseModel):
    run_id: str
    workflow_id: str
    status: str
    execution_log: list[dict[str, Any]] = Field(default_factory=list)
    error_message: Optional[str] = None
