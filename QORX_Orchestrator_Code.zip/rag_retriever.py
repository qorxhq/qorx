"""
QORX AI Decision Engine — RAG retriever.

Retrieves business context (glossary terms, metric definitions, org memory,
prior Q&A) via hybrid search (pgvector cosine + trigram keyword) so the LLM
answers using the customer's own business vocabulary and never invents
metric definitions.
"""
from __future__ import annotations
from typing import Any

import asyncpg

from .schemas import RetrievedContext


class RAGRetriever:
    def __init__(self, db_pool: asyncpg.Pool, embed_fn):
        """
        embed_fn: async callable(str) -> list[float], wired to Voyage/OpenAI embeddings.
        """
        self.db_pool = db_pool
        self.embed_fn = embed_fn

    async def retrieve(self, org_id: str, query: str, top_k: int = 8) -> RetrievedContext:
        query_embedding = await self.embed_fn(query)

        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)

            glossary_rows = await conn.fetch(
                """
                SELECT term, definition, related_metric_id,
                       1 - (embedding <=> $2) AS similarity
                FROM business_glossary
                WHERE org_id = $1
                ORDER BY embedding <=> $2
                LIMIT $3
                """,
                org_id, query_embedding, top_k,
            )

            metric_rows = await conn.fetch(
                """
                SELECT metric_id, display_name, unit, aggregation, formula, grain
                FROM metric_definitions
                WHERE org_id = $1 AND is_active = true
                ORDER BY similarity(display_name, $2) DESC
                LIMIT $3
                """,
                org_id, query, top_k,
            )

            memory_rows = await conn.fetch(
                """
                SELECT fact, 1 - (embedding <=> $2) AS similarity
                FROM org_memory
                WHERE org_id = $1
                ORDER BY embedding <=> $2
                LIMIT 5
                """,
                org_id, query_embedding,
            )

            prior_qa_rows = await conn.fetch(
                """
                SELECT m1.content AS question, m2.content AS answer
                FROM messages m1
                JOIN messages m2 ON m2.conversation_id = m1.conversation_id
                                 AND m2.message_id > m1.message_id AND m2.role = 'assistant'
                JOIN conversations c ON c.conversation_id = m1.conversation_id
                WHERE c.org_id = $1 AND m1.role = 'user'
                ORDER BY m1.created_at DESC
                LIMIT 5
                """,
                org_id,
            )

        return RetrievedContext(
            glossary_terms=[dict(r) for r in glossary_rows],
            metric_definitions=[dict(r) for r in metric_rows],
            org_memory_facts=[r["fact"] for r in memory_rows],
            prior_qa=[dict(r) for r in prior_qa_rows],
        )

    @staticmethod
    def format_as_system_context(context: RetrievedContext) -> str:
        """Renders retrieved context into a compact system-prompt block."""
        parts: list[str] = []

        if context.metric_definitions:
            parts.append("AVAILABLE METRICS:\n" + "\n".join(
                f"- {m['metric_id']} ({m['display_name']}, unit={m['unit']}, "
                f"agg={m['aggregation']}, grain={m['grain']})"
                for m in context.metric_definitions
            ))

        if context.glossary_terms:
            parts.append("BUSINESS GLOSSARY:\n" + "\n".join(
                f"- {g['term']}: {g['definition']}" for g in context.glossary_terms
            ))

        if context.org_memory_facts:
            parts.append("KNOWN ORG FACTS:\n" + "\n".join(f"- {f}" for f in context.org_memory_facts))

        return "\n\n".join(parts)
