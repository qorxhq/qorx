"""
QORX AI Decision Engine — Orchestrator.

A LangGraph-style state machine:

    classify_intent -> retrieve_context -> plan_tools -> execute_tools
        -> synthesize_answer -> END

Each node is a pure function over OrchestratorState. Swap in `langgraph.graph.StateGraph`
directly if you want built-in checkpointing/streaming; the node functions below are
already shaped as `(state) -> state` so the migration is mechanical.
"""
from __future__ import annotations
import json
from typing import Any

import anthropic

from .schemas import (
    ChatResponse,
    IntentType,
    OrchestratorState,
    ToolCall,
)
from .tools import ANTHROPIC_MODEL_FAST, ANTHROPIC_MODEL_REASONING, TOOL_SPECS, ToolRegistry
from .rag_retriever import RAGRetriever

SYSTEM_PROMPT_BASE = """You are QORX, an AI Decision Intelligence engine.
You never fabricate numbers. Every numeric claim MUST come from a tool call result.
When you answer, explain WHY something happened, WHAT will likely happen next, and
WHAT the user should do about it — not just what the numbers are.
Use the business's own terminology from the glossary provided in context.
If you are not confident, say so explicitly and state what data would resolve the uncertainty."""


class QorxOrchestrator:
    def __init__(self, anthropic_client: anthropic.AsyncAnthropic,
                 tool_registry: ToolRegistry, retriever: RAGRetriever):
        self.client = anthropic_client
        self.tools = tool_registry
        self.retriever = retriever

    async def run(self, org_id: str, user_id: str, conversation_id: str, message: str) -> ChatResponse:
        state = OrchestratorState(
            org_id=org_id, user_id=user_id,
            conversation_id=conversation_id, user_message=message,
        )
        state = await self._classify_intent(state)
        state = await self._retrieve_context(state)
        state = await self._plan_tools(state)
        state = await self._execute_tools(state)
        state = await self._synthesize_answer(state)

        return ChatResponse(
            conversation_id=state.conversation_id,
            answer=state.final_answer or "",
            chart_spec=state.chart_spec,
            confidence=state.confidence,
            suggested_action=state.suggested_action,
            tool_calls_made=[t.tool_name for t in state.tool_results],
        )

    # ------------------------------------------------------------------
    # Node 1: classify intent (cheap model — Haiku)
    # ------------------------------------------------------------------
    async def _classify_intent(self, state: OrchestratorState) -> OrchestratorState:
        resp = await self.client.messages.create(
            model=ANTHROPIC_MODEL_FAST,
            max_tokens=20,
            system="Classify the user's question into exactly one word: "
                   "diagnostic, predictive, prescriptive, or lookup. Reply with only that word.",
            messages=[{"role": "user", "content": state.user_message}],
        )
        raw = resp.content[0].text.strip().lower()
        try:
            state.intent = IntentType(raw)
        except ValueError:
            state.intent = IntentType.LOOKUP
        state.log(f"intent classified as {state.intent}")
        return state

    # ------------------------------------------------------------------
    # Node 2: retrieve context (RAG)
    # ------------------------------------------------------------------
    async def _retrieve_context(self, state: OrchestratorState) -> OrchestratorState:
        state.context = await self.retriever.retrieve(state.org_id, state.user_message)
        state.log(f"retrieved {len(state.context.metric_definitions)} metrics, "
                   f"{len(state.context.glossary_terms)} glossary terms")
        return state

    # ------------------------------------------------------------------
    # Node 3: plan tool calls (reasoning model — Sonnet, with tool use)
    # ------------------------------------------------------------------
    async def _plan_tools(self, state: OrchestratorState) -> OrchestratorState:
        system = SYSTEM_PROMPT_BASE + "\n\n" + RAGRetriever.format_as_system_context(state.context)

        resp = await self.client.messages.create(
            model=ANTHROPIC_MODEL_REASONING,
            max_tokens=1024,
            system=system,
            tools=TOOL_SPECS,
            messages=[{"role": "user", "content": state.user_message}],
        )

        for block in resp.content:
            if block.type == "tool_use":
                state.planned_tool_calls.append(ToolCall(tool_name=block.name, arguments=block.input))

        state.log(f"planned {len(state.planned_tool_calls)} tool calls: "
                   f"{[t.tool_name for t in state.planned_tool_calls]}")
        return state

    # ------------------------------------------------------------------
    # Node 4: execute tools
    # ------------------------------------------------------------------
    async def _execute_tools(self, state: OrchestratorState) -> OrchestratorState:
        for call in state.planned_tool_calls:
            result = await self.tools.dispatch(state.org_id, call.tool_name, call.arguments)
            state.tool_results.append(result)
            state.log(f"executed {call.tool_name} -> "
                       f"{'error: ' + result.error if result.error else 'ok'}")
        return state

    # ------------------------------------------------------------------
    # Node 5: synthesize final answer (reasoning model, grounded in tool results)
    # ------------------------------------------------------------------
    async def _synthesize_answer(self, state: OrchestratorState) -> OrchestratorState:
        system = SYSTEM_PROMPT_BASE + "\n\n" + RAGRetriever.format_as_system_context(state.context)
        system += (
            "\n\nRespond in JSON with keys: answer (string), confidence (0-1 float), "
            "suggested_action (string or null), chart_spec (object or null describing "
            "a chart of the form {type, x_field, y_field, data} or null if not needed). "
            "Return ONLY the JSON object, no other text."
        )

        tool_results_payload = json.dumps(
            [{"tool": r.tool_name, "result": r.result, "error": r.error} for r in state.tool_results],
            default=str,
        )

        resp = await self.client.messages.create(
            model=ANTHROPIC_MODEL_REASONING,
            max_tokens=1500,
            system=system,
            messages=[
                {"role": "user", "content": state.user_message},
                {"role": "user", "content": f"Tool results:\n{tool_results_payload}"},
            ],
        )

        try:
            parsed: dict[str, Any] = json.loads(resp.content[0].text)
        except (json.JSONDecodeError, IndexError):
            parsed = {"answer": resp.content[0].text if resp.content else "No answer generated.",
                      "confidence": None, "suggested_action": None, "chart_spec": None}

        state.final_answer = parsed.get("answer")
        state.confidence = parsed.get("confidence")
        state.suggested_action = parsed.get("suggested_action")
        state.chart_spec = parsed.get("chart_spec")
        state.log("synthesized final answer")
        return state
