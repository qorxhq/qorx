"""
QORX AI Decision Engine — tool implementations.

Every tool is read-only against the UDM / metrics engine. The LLM never
writes to the database and never fabricates numbers — every numeric claim
in the final answer must trace back to one of these tool results.
"""
from __future__ import annotations
import statistics
from datetime import date, timedelta
from typing import Any

import asyncpg

from .action_engine import ActionEngine
from .schemas import (
    ExecuteWorkflowArgs,
    ForecastArgs,
    GenerateSQLArgs,
    MetricQueryArgs,
    ProposeWorkflowArgs,
    RootCauseArgs,
    ToolResult,
    WorkflowDefinition,
)

ANTHROPIC_MODEL_FAST = "claude-haiku-4-5-20251001"     # routing / classification
ANTHROPIC_MODEL_REASONING = "claude-sonnet-5"           # synthesis / reasoning


class ToolRegistry:
    """Registers callable tools and dispatches by name for the orchestrator."""

    def __init__(self, db_pool: asyncpg.Pool, action_engine: ActionEngine | None = None):
        self.db_pool = db_pool
        self.action_engine = action_engine

    async def dispatch(self, org_id: str, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        handler = getattr(self, f"tool_{tool_name}", None)
        if handler is None:
            return ToolResult(tool_name=tool_name, result={}, error=f"Unknown tool: {tool_name}")
        try:
            result = await handler(org_id, arguments)
            return ToolResult(tool_name=tool_name, result=result)
        except Exception as exc:  # noqa: BLE001 — surfaced to the LLM as an error string
            return ToolResult(tool_name=tool_name, result={}, error=str(exc))

    # ------------------------------------------------------------------
    # 1. query_metric
    # ------------------------------------------------------------------
    async def tool_query_metric(self, org_id: str, arguments: dict) -> dict:
        args = MetricQueryArgs(**arguments)

        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)

            metric_row = await conn.fetchrow(
                """
                SELECT metric_id, display_name, unit, aggregation, source_entity,
                       source_field, formula, grain
                FROM metric_definitions
                WHERE org_id = $1 AND metric_id = $2 AND is_active = true
                ORDER BY version DESC LIMIT 1
                """,
                org_id, args.metric_id,
            )
            if metric_row is None:
                return {"error": f"Metric '{args.metric_id}' is not defined for this org"}

            sql, sql_params = self._compile_metric_sql(metric_row, args)
            rows = await conn.fetch(sql, *sql_params)

            return {
                "metric_id": args.metric_id,
                "display_name": metric_row["display_name"],
                "unit": metric_row["unit"],
                "timeframe": {"start": str(args.start), "end": str(args.end)},
                "data": [dict(r) for r in rows],
            }

    def _compile_metric_sql(self, metric_row, args: MetricQueryArgs) -> tuple[str, list]:
        """Compiles a metric definition + query args into parameterized SQL.
        In production this goes through the full semantic-layer compiler
        (joins, glossary filters, dimension resolution). Simplified here."""
        agg_map = {
            "sum": "SUM", "avg": "AVG", "count": "COUNT",
            "count_distinct": "COUNT DISTINCT", "min": "MIN", "max": "MAX",
        }
        agg_fn = agg_map.get(metric_row["aggregation"], "SUM")
        group_cols = ", ".join(args.group_by) if args.group_by else "NULL"

        sql = f"""
            SELECT {group_cols} AS group_key,
                   date_trunc('{metric_row["grain"]}', occurred_at) AS period,
                   {agg_fn}((payload->>'{metric_row["source_field"]}')::numeric) AS value
            FROM events
            WHERE org_id = $1
              AND event_type = $2
              AND occurred_at BETWEEN $3 AND $4
            GROUP BY 1, 2
            ORDER BY 2
        """
        return sql, [metric_row["org_id"] if "org_id" in metric_row else args.metric_id,
                      metric_row["source_entity"], args.start, args.end]

    # ------------------------------------------------------------------
    # 2. root_cause_analysis — variance decomposition (MVP version)
    # ------------------------------------------------------------------
    async def tool_root_cause_analysis(self, org_id: str, arguments: dict) -> dict:
        args = RootCauseArgs(**arguments)

        period_a = await self.tool_query_metric(org_id, {
            "metric_id": args.metric_id, "start": str(args.period_a_start),
            "end": str(args.period_a_end), "group_by": ["dimension"],
        })
        period_b = await self.tool_query_metric(org_id, {
            "metric_id": args.metric_id, "start": str(args.period_b_start),
            "end": str(args.period_b_end), "group_by": ["dimension"],
        })

        a_by_dim = {r["group_key"]: r["value"] for r in period_a.get("data", [])}
        b_by_dim = {r["group_key"]: r["value"] for r in period_b.get("data", [])}

        total_delta = sum(b_by_dim.values()) - sum(a_by_dim.values())
        contributions = []
        for dim in set(a_by_dim) | set(b_by_dim):
            delta = b_by_dim.get(dim, 0) - a_by_dim.get(dim, 0)
            contributions.append({
                "dimension_value": dim,
                "delta": delta,
                "pct_of_total_change": round(delta / total_delta * 100, 1) if total_delta else 0,
            })
        contributions.sort(key=lambda c: abs(c["delta"]), reverse=True)

        return {
            "metric_id": args.metric_id,
            "total_delta": total_delta,
            "top_drivers": contributions[:5],
        }

    # ------------------------------------------------------------------
    # 3. forecast_metric
    # ------------------------------------------------------------------
    async def tool_forecast_metric(self, org_id: str, arguments: dict) -> dict:
        args = ForecastArgs(**arguments)
        history_end = date.today()
        history_start = history_end - timedelta(days=180)

        history = await self.tool_query_metric(org_id, {
            "metric_id": args.metric_id, "start": str(history_start),
            "end": str(history_end), "group_by": [],
        })
        values = [r["value"] for r in history.get("data", []) if r["value"] is not None]
        if len(values) < 14:
            return {"error": "Not enough history to forecast reliably (need >= 14 periods)"}

        # MVP baseline: naive trend + seasonal-naive blend.
        # Production: statsforecast AutoETS / Prophet, swapped in behind this same interface.
        recent_avg = statistics.mean(values[-14:])
        trend = (statistics.mean(values[-7:]) - statistics.mean(values[-14:-7])) / 7
        forecast_points = [
            {"day_offset": i, "forecast": round(recent_avg + trend * i, 2)}
            for i in range(1, args.horizon_days + 1)
        ]
        stdev = statistics.pstdev(values[-30:]) if len(values) >= 30 else statistics.pstdev(values)

        return {
            "metric_id": args.metric_id,
            "horizon_days": args.horizon_days,
            "forecast": forecast_points,
            "confidence_interval_pct95": round(stdev * 1.96, 2),
            "method": "naive_trend_baseline_mvp",
        }

    # ------------------------------------------------------------------
    # 4. generate_sql — NL to validated read-only SQL over the UDM
    # ------------------------------------------------------------------
    async def tool_generate_sql(self, org_id: str, arguments: dict) -> dict:
        args = GenerateSQLArgs(**arguments)
        # In production this calls the LLM with the semantic model + schema as
        # context, then validates the result is SELECT-only before execution.
        generated_sql = await self._llm_generate_sql(args.natural_language_question, org_id)
        if not self._is_read_only(generated_sql):
            return {"error": "Generated query was rejected: not read-only"}

        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            rows = await conn.fetch(generated_sql)
            return {"sql": generated_sql, "rows": [dict(r) for r in rows][:200]}

    @staticmethod
    def _is_read_only(sql: str) -> bool:
        forbidden = ("insert", "update", "delete", "drop", "alter", "truncate", "grant")
        lowered = sql.strip().lower()
        return lowered.startswith("select") and not any(f in lowered for f in forbidden)

    async def _llm_generate_sql(self, question: str, org_id: str) -> str:
        """Placeholder — calls Claude with schema + semantic context to produce SQL.
        Wired to the real Anthropic client in production; stubbed here for clarity."""
        raise NotImplementedError("Wire to Anthropic client with schema-aware system prompt")

    # ------------------------------------------------------------------
    # 5. propose_workflow — Action Engine: AI drafts an automation from
    #    a conversation instead of the user building it node-by-node (n8n-style)
    # ------------------------------------------------------------------
    async def tool_propose_workflow(self, org_id: str, arguments: dict) -> dict:
        if self.action_engine is None:
            return {"error": "Action Engine is not enabled for this deployment"}
        args = ProposeWorkflowArgs(**arguments)
        definition = WorkflowDefinition(
            org_id=org_id, name=args.name, description=args.description,
            trigger_type=args.trigger_type, trigger_config=args.trigger_config,
            action_steps=args.action_steps, requires_approval=True,  # AI-proposed workflows always start gated
            created_by="ai_suggested", source_insight_id=args.source_insight_id,
        )
        workflow_id = await self.action_engine.create_workflow(definition)
        return {
            "workflow_id": workflow_id,
            "status": "created_pending_first_approval",
            "note": "This workflow will not run automatically until a user approves its first execution.",
        }

    # ------------------------------------------------------------------
    # 6. execute_workflow — manual/on-demand trigger of an existing workflow
    # ------------------------------------------------------------------
    async def tool_execute_workflow(self, org_id: str, arguments: dict) -> dict:
        if self.action_engine is None:
            return {"error": "Action Engine is not enabled for this deployment"}
        args = ExecuteWorkflowArgs(**arguments)
        async with self.db_pool.acquire() as conn:
            await conn.execute("SET app.current_org_id = $1", org_id)
            row = await conn.fetchrow(
                """
                INSERT INTO workflow_runs (workflow_id, org_id, triggered_by, status)
                VALUES ($1, $2, $3, 'pending_approval') RETURNING run_id
                """,
                args.workflow_id, org_id, {"type": "manual"},
            )
        return {
            "run_id": str(row["run_id"]),
            "status": "pending_approval",
            "note": "Awaiting explicit user approval before execution.",
        }


TOOL_SPECS = [
    {
        "name": "query_metric",
        "description": "Query a defined business metric with filters, timeframe, and optional grouping.",
        "input_schema": MetricQueryArgs.model_json_schema(),
    },
    {
        "name": "root_cause_analysis",
        "description": "Decompose the change in a metric between two periods into contributing dimensions.",
        "input_schema": RootCauseArgs.model_json_schema(),
    },
    {
        "name": "forecast_metric",
        "description": "Forecast a metric N days ahead with a confidence interval.",
        "input_schema": ForecastArgs.model_json_schema(),
    },
    {
        "name": "generate_sql",
        "description": "Convert a natural-language question into validated read-only SQL over the UDM.",
        "input_schema": GenerateSQLArgs.model_json_schema(),
    },
    {
        "name": "propose_workflow",
        "description": (
            "Draft a new automation (trigger + action steps) from the conversation, e.g. "
            "'email the regional manager whenever sellout drops under target for 3 days'. "
            "This replaces manually building the automation in a separate tool like n8n/Zapier. "
            "The workflow is always created in a pending-approval state — it never runs "
            "automatically until a user explicitly approves its first execution."
        ),
        "input_schema": ProposeWorkflowArgs.model_json_schema(),
    },
    {
        "name": "execute_workflow",
        "description": "Manually trigger an existing, already-defined workflow on demand.",
        "input_schema": ExecuteWorkflowArgs.model_json_schema(),
    },
]
